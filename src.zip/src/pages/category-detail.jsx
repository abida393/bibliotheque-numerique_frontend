import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Folder, ArrowLeft } from 'lucide-react'
import { api } from '@/lib/api'
import { ResourceCard } from '@/components/resource-card'
import { EmptyState } from '@/components/empty-state'
import { Spinner } from '@/components/ui/spinner'

export function CategoryDetailPage() {
  const { id } = useParams()
  const [category, setCategory] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function load() {
      setLoading(true)
      try {
        const res = await api.get(`/categories/${id}`)
        setCategory(res.data)
      } catch (err) {
        setError(err.message ?? 'Erreur lors du chargement de la catégorie.')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [id])

  if (loading) return (
    <div className="flex justify-center py-32">
      <Spinner className="size-8" />
    </div>
  )

  if (error) return (
    <div className="mx-auto max-w-6xl px-4 py-16 text-center">
      <p className="text-destructive">{error}</p>
      <Link to="/" className="mt-4 inline-block text-sm font-medium text-primary hover:underline">
        Retour au catalogue
      </Link>
    </div>
  )

  if (!category) return null

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <Link to="/" className="mb-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="size-4" /> Retour au catalogue
      </Link>

      <div className="mb-8">
        <h1 className="flex items-center gap-3 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
          <span className="inline-flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Folder className="size-5" />
          </span>
          {category.name}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">Explorez les ressources de cette catégorie.</p>
      </div>

      {category.children?.length > 0 && (
        <div className="mb-8">
          <h2 className="mb-3 text-sm font-semibold tracking-wide text-muted-foreground uppercase">Sous-catégories</h2>
          <div className="flex flex-wrap gap-2">
            {category.children.map(child => (
              <Link
                key={child.id}
                to={`/categories/${child.id}`}
                className="inline-flex items-center rounded-lg border border-border bg-card px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:border-primary/50 hover:bg-muted"
              >
                {child.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      <div>
        <h2 className="mb-4 text-lg font-semibold text-foreground">Ressources ({category.resources?.length ?? 0})</h2>
        
        {!category.resources || category.resources.length === 0 ? (
          <EmptyState onReset={() => window.history.back()} />
        ) : (
          <ul className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {category.resources.map(resource => (
              <li key={resource.id}>
                <ResourceCard resource={resource} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  )
}
