/**
 * FavoritesContext — global favorites state with optimistic updates.
 * Fetches all favorited resource IDs on mount (up to 5 pages = 100 resources).
 */
/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useEffect, useState } from 'react'
import { api } from '@/lib/api'
import { useAuth } from './auth-context'

const FavoritesContext = createContext(null)

export function FavoritesProvider({ children }) {
  const { isAuthenticated } = useAuth()
  const [ids, setIds] = useState(new Set())
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isAuthenticated) { setLoading(false); return }

    async function fetchAll() {
      setLoading(true)
      try {
        let page = 1
        const collected = new Set()
        while (page <= 5) {
          const res = await api.get('/favorites', { page })
          ;(res.data ?? []).forEach(r => collected.add(r.id))
          if (page >= (res.meta?.last_page ?? 1)) break
          page++
        }
        setIds(collected)
      } catch { /* silent — favorites not critical */ }
      finally { setLoading(false) }
    }
    fetchAll()
  }, [isAuthenticated])

  async function toggle(resourceId) {
    const was = ids.has(resourceId)
    // Optimistic
    setIds(prev => {
      const n = new Set(prev)
      if (was) n.delete(resourceId); else n.add(resourceId)
      return n
    })
    try {
      if (was) await api.delete(`/resources/${resourceId}/favorite`)
      else await api.post(`/resources/${resourceId}/favorite`)
    } catch {
      // Rollback
      setIds(prev => {
        const n = new Set(prev)
        if (was) n.add(resourceId); else n.delete(resourceId)
        return n
      })
    }
  }

  return (
    <FavoritesContext.Provider value={{ ids, loading, toggle }}>
      {children}
    </FavoritesContext.Provider>
  )
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext)
  if (!ctx) throw new Error('useFavorites must be inside <FavoritesProvider>')
  return ctx
}
